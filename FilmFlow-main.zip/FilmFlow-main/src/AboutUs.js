import React from 'react';

export default function (props) {
    return (
        <div className = "about-us-page">
            <p className= "about_headers">Created By:</p>
            <p className="about_devduo">DevDuo</p>
            <p className= "about_headers">Members:</p>
            <p className="about_members">Weston Winkeljohn</p>
            <p className="about_members">Chris Statton</p>
        </div>
    )
}